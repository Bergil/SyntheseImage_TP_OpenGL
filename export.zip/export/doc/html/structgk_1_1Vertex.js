var structgk_1_1Vertex =
[
    [ "Vertex", "structgk_1_1Vertex.html#a109f7d4d67bd5e4cc7ecc83a0526ca30", null ],
    [ "Vertex", "structgk_1_1Vertex.html#a07279c7439a08b0037593eaa0265515e", null ],
    [ "operator<", "structgk_1_1Vertex.html#a6e1330001c127bc09a5c81f246e4088c", null ],
    [ "material", "structgk_1_1Vertex.html#afb5dc69ddca882148556cd8d6e718b97", null ],
    [ "normal", "structgk_1_1Vertex.html#a7dbd650bff63bcdc7221f3bc17d643a7", null ],
    [ "position", "structgk_1_1Vertex.html#a320f86b933dcb0d3da194b7eac8b4dd0", null ],
    [ "texcoord", "structgk_1_1Vertex.html#a6014473463a0bcc2c86a64a0f7fc6b07", null ]
];