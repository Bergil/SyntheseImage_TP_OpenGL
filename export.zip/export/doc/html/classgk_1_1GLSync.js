var classgk_1_1GLSync =
[
    [ "GLSync", "classgk_1_1GLSync.html#aa533fafa86899e670332c2046640a974", null ],
    [ "GLSync", "classgk_1_1GLSync.html#a6de52166afdfc922a0ded80962dc4ed5", null ],
    [ "clientSync", "classgk_1_1GLSync.html#a3544ba155df726e814c5779179653895", null ],
    [ "create", "classgk_1_1GLSync.html#a5c09a6fd3f60612b9f5f5fd977b3047f", null ],
    [ "release", "classgk_1_1GLSync.html#ad94f0cc5dad7f34faac3d921a9923f28", null ],
    [ "sync", "classgk_1_1GLSync.html#ac7e48e08231695063fd397640bca08ba", null ],
    [ "condition", "classgk_1_1GLSync.html#a5552da5dfcd7eeed1ce4a74b1def0f67", null ],
    [ "fence", "classgk_1_1GLSync.html#ae916dc688d62f45c95f0b4e28be6dcdc", null ],
    [ "flags", "classgk_1_1GLSync.html#a48821f9814f71157b54fc03d973f61b8", null ]
];