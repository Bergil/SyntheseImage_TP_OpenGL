var structnv_1_1Group =
[
    [ "bounds", "structnv_1_1Group.html#a9f0fe6151df54e21ac3cfc8766be9ddc", null ],
    [ "flags", "structnv_1_1Group.html#a4a53c5c3eae4279de760640f620aba92", null ],
    [ "margin", "structnv_1_1Group.html#a9eda970443ba822e1af65b6415bb76c6", null ],
    [ "space", "structnv_1_1Group.html#aed78ca017ffac10bc23b401cd6db5745", null ]
];