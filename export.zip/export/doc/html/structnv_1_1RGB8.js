var structnv_1_1RGB8 =
[
    [ "RGB8", "structnv_1_1RGB8.html#ab4cb382bcd772b6f90223401f8f5b957", null ],
    [ "RGB8", "structnv_1_1RGB8.html#ab9828f9fa44c7aacf34b4d170e47dc10", null ],
    [ "RGB8", "structnv_1_1RGB8.html#abd04d94935e5d6bbfb2689c9d1ae95a9", null ],
    [ "RGB8", "structnv_1_1RGB8.html#aa259b2e76d3d3054adef91dae50f78b5", null ],
    [ "clamp", "structnv_1_1RGB8.html#a237fd49f91b9342217d8a65d0b2b8b4a", null ],
    [ "operator=", "structnv_1_1RGB8.html#a0d12edd26e01e48a35d3a83d7c953a26", null ],
    [ "a", "structnv_1_1RGB8.html#a0dc3e434843a93c13e026f93bbcc0ebd", null ],
    [ "b", "structnv_1_1RGB8.html#a35bc72d49ebbc5c3ed198c8d4ea8d792", null ],
    [ "g", "structnv_1_1RGB8.html#ab260fef8b35c23803cc689eed7741aac", null ],
    [ "r", "structnv_1_1RGB8.html#a597d7d35a2c2863c4a8bcd2b5608da07", null ]
];