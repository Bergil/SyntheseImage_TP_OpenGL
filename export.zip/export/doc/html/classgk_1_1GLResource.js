var classgk_1_1GLResource =
[
    [ "GLResource", "classgk_1_1GLResource.html#a843660ed745b7b8d1c1df88196611a34", null ],
    [ "GLResource", "classgk_1_1GLResource.html#a0f610503b861b13d0cf48092d50b2f78", null ],
    [ "GLResource", "classgk_1_1GLResource.html#af5c158b301aeb65d745a99ed0f5eb79c", null ],
    [ "~GLResource", "classgk_1_1GLResource.html#a4b1254943193760967339ea9e720c981", null ],
    [ "manage", "classgk_1_1GLResource.html#a9de099aa021037641c0594c2d65c35e0", null ],
    [ "release", "classgk_1_1GLResource.html#af7361f4c8a06e8d2c1c944e89db2acfe", null ],
    [ "label", "classgk_1_1GLResource.html#ae143e99326a052360f253f2ed11d298c", null ],
    [ "name", "classgk_1_1GLResource.html#a50554965fb870d3e3cdb166824748a8e", null ]
];