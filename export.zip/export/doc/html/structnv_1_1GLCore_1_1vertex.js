var structnv_1_1GLCore_1_1vertex =
[
    [ "vertex", "structnv_1_1GLCore_1_1vertex.html#aea3433a7b32025519f8580d8ad851aa3", null ],
    [ "vertex", "structnv_1_1GLCore_1_1vertex.html#ac2f841deeec843ac2fa0abdda4178823", null ],
    [ "p", "structnv_1_1GLCore_1_1vertex.html#a9f451327c92ebf2010279060a33bbe7c", null ],
    [ "s", "structnv_1_1GLCore_1_1vertex.html#adcda33116eb0ee9519c158dc6c245054", null ],
    [ "t", "structnv_1_1GLCore_1_1vertex.html#a6ba1a93f3ef1866bb6e0df3765c71fe6", null ],
    [ "x", "structnv_1_1GLCore_1_1vertex.html#a601138165891152f9db08dbcface5ab4", null ],
    [ "y", "structnv_1_1GLCore_1_1vertex.html#a9441a88eea34804ede6158d6fefafa69", null ]
];