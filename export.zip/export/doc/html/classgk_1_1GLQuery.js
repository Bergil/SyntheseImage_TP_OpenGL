var classgk_1_1GLQuery =
[
    [ "GLQuery", "classgk_1_1GLQuery.html#a67ebebec8a5bebd1786f6d031b595043", null ],
    [ "GLQuery", "classgk_1_1GLQuery.html#a69f372b8c93cfc71e6fcb9b6ac37870e", null ],
    [ "~GLQuery", "classgk_1_1GLQuery.html#a4af610a1f89d26557c9fb797369dea5f", null ],
    [ "available", "classgk_1_1GLQuery.html#a709779cb619fcc512b5136157aa01529", null ],
    [ "begin", "classgk_1_1GLQuery.html#a3f2925f57f3935fefad064bbfa94054d", null ],
    [ "create", "classgk_1_1GLQuery.html#a7c9d1a3a9e6fd8a94375dd360dedeacd", null ],
    [ "end", "classgk_1_1GLQuery.html#a94f9c6e354f8c004c0336f701aceff6e", null ],
    [ "release", "classgk_1_1GLQuery.html#a97ebf1354d0526dbea04511e45804465", null ],
    [ "result", "classgk_1_1GLQuery.html#a28c83cb172d140eb28d9e8088cbd0366", null ],
    [ "result64", "classgk_1_1GLQuery.html#a8a984d586bb4ac912d50901f4dd5daf3", null ],
    [ "state", "classgk_1_1GLQuery.html#a8e0d92a7b0d61c5ec3db8cd2a4fbec33", null ],
    [ "summary", "classgk_1_1GLQuery.html#a8cdfad7e8d5f517bc9e27935bd9cc660", null ],
    [ "sync", "classgk_1_1GLQuery.html#a7bdda373b39f14475a647bb94af3dcc8", null ],
    [ "cpu_start", "classgk_1_1GLQuery.html#a09aa82cbdcf08a6dfd8ad7068ccfa126", null ],
    [ "cpu_stop", "classgk_1_1GLQuery.html#a9f418228a4b3ada8b138d0056b96d4ab", null ],
    [ "started", "classgk_1_1GLQuery.html#a16bd41596c8464ccf3f3140fd966d50c", null ],
    [ "target", "classgk_1_1GLQuery.html#ace58692c2c7b5ad4980a2deef5d63ae5", null ],
    [ "value", "classgk_1_1GLQuery.html#aaa7e3b367db29dc59227babf47847032", null ]
];