var structgk_1_1glsl_1_1grmat =
[
    [ "operator const T *", "structgk_1_1glsl_1_1grmat.html#a8657d6b9bc7707cba4221f52c2ae9e16", null ],
    [ "operator T *", "structgk_1_1glsl_1_1grmat.html#ac7253a679fcb5a633d868d1c161f7d2b", null ],
    [ "operator[]", "structgk_1_1glsl_1_1grmat.html#a25459f35f6d11f71db4c3efe46d5dc81", null ],
    [ "operator[]", "structgk_1_1glsl_1_1grmat.html#a9bc9e0edcd8693e253144906cf24f4e7", null ],
    [ "row", "structgk_1_1glsl_1_1grmat.html#aafc6d5656870e4b127caaf18937b1a2b", null ]
];