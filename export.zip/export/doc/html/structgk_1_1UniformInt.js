var structgk_1_1UniformInt =
[
    [ "UniformInt", "structgk_1_1UniformInt.html#a2879e4a604882332a7c7d2b1a485b1cb", null ],
    [ "operator=", "structgk_1_1UniformInt.html#a212dd60097610d4f144684ebeb887a4b", null ],
    [ "update", "structgk_1_1UniformInt.html#ac0cd7f6d179b41739e5125464782e670", null ]
];