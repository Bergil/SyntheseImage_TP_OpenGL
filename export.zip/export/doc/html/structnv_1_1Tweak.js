var structnv_1_1Tweak =
[
    [ "Tweak", "structnv_1_1Tweak.html#a5d784ce7ab377de8622026a39b41598f", null ],
    [ "Tweak", "structnv_1_1Tweak.html#addbbd79a247f55bf39be6c56f32f1aba", null ],
    [ "~Tweak", "structnv_1_1Tweak.html#aa9288d9974211fd607f7cbe39100a437", null ],
    [ "doTweak", "structnv_1_1Tweak.html#a0b734ff9432afa37a000530cecbf7cb9", null ],
    [ "label", "structnv_1_1Tweak.html#a003f6685427d2a8e87092104af8dd030", null ],
    [ "max", "structnv_1_1Tweak.html#af054524c739fc3635e7c6f4817dff407", null ],
    [ "min", "structnv_1_1Tweak.html#a70f479080c0725f6bc7992e7861bd5a6", null ],
    [ "step", "structnv_1_1Tweak.html#addad983bff076c39561a250ffaa63623", null ],
    [ "value", "structnv_1_1Tweak.html#ad3ae2f9e29f5c7c2a7e14435de93e961", null ]
];