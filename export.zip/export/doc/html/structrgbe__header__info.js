var structrgbe__header__info =
[
    [ "exposure", "structrgbe__header__info.html#a9c1db6de28b6ce3b566d5806bccf8949", null ],
    [ "gamma", "structrgbe__header__info.html#ae12262c6fc7feb14256d283a4ade0549", null ],
    [ "programtype", "structrgbe__header__info.html#a760eac48bb32dda3d001efea7244605f", null ],
    [ "valid", "structrgbe__header__info.html#a439424490ca2bf8ebf0ed12f7b92884f", null ]
];