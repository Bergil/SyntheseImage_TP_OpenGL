var structgk_1_1Edge =
[
    [ "Edge", "structgk_1_1Edge.html#aed8491db2034de32331304cee4e1441d", null ],
    [ "Edge", "structgk_1_1Edge.html#a954a0560cd34d5690fbf55c244bc8f21", null ],
    [ "a", "structgk_1_1Edge.html#a6bff50566a591e9a9276adcbb9a51847", null ],
    [ "b", "structgk_1_1Edge.html#a9b44bd4b72086451980db0e164782dfb", null ],
    [ "face", "structgk_1_1Edge.html#a1f3791d4616e9d10569add58026a77c8", null ],
    [ "id", "structgk_1_1Edge.html#a9c6a438bdf311e07500dd422954340da", null ]
];