var structgk_1_1UniformMat4 =
[
    [ "UniformMat4", "structgk_1_1UniformMat4.html#af71230fa9b28a45b44f51b5dde2f6f8d", null ],
    [ "operator=", "structgk_1_1UniformMat4.html#a630f996431ad0b660d6d7aa2722d9678", null ],
    [ "update", "structgk_1_1UniformMat4.html#ab6b67766f32478053a2edc04e78cc261", null ]
];