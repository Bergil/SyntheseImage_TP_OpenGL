var structgk_1_1MeshMaterial =
[
    [ "MeshMaterial", "structgk_1_1MeshMaterial.html#af93af3d276c5d0836c03336d003f2b73", null ],
    [ "MeshMaterial", "structgk_1_1MeshMaterial.html#ad2083fdc9af9bbe5c8b77489d276f54a", null ],
    [ "ambient_color", "structgk_1_1MeshMaterial.html#a969876e204716ce6a12b2020ee1c236c", null ],
    [ "ambient_texture", "structgk_1_1MeshMaterial.html#ae07e8d9ac3ca95e5c71c02fb03fd6a18", null ],
    [ "diffuse_color", "structgk_1_1MeshMaterial.html#a41f241b6e846b6a9daab1461a1a8c53b", null ],
    [ "diffuse_texture", "structgk_1_1MeshMaterial.html#aebf0e1494e8caa88065fec58f85c94a6", null ],
    [ "emission", "structgk_1_1MeshMaterial.html#adb119d4b22bfa2f0b41dd06170a88e4c", null ],
    [ "ka", "structgk_1_1MeshMaterial.html#a3c933544d26e1438d35b887c70301bfb", null ],
    [ "kd", "structgk_1_1MeshMaterial.html#a502067bb83902bf2e902b3dabac07a97", null ],
    [ "ks", "structgk_1_1MeshMaterial.html#a64fe67fceb8cbd56c9bc745aeb651699", null ],
    [ "name", "structgk_1_1MeshMaterial.html#a4d034e3d78861642e3069e547fc7bc57", null ],
    [ "ni", "structgk_1_1MeshMaterial.html#a13eba72dfcf0d26e2d8566f1e997752a", null ],
    [ "ns", "structgk_1_1MeshMaterial.html#a2f0b6532fbe9c3df8aef2aca3f200cda", null ],
    [ "specular_color", "structgk_1_1MeshMaterial.html#affa5cbb04125ca6092d2ac8d61b37a34", null ],
    [ "specular_texture", "structgk_1_1MeshMaterial.html#a854fd14320857785663690ad0c0b75ee", null ]
];