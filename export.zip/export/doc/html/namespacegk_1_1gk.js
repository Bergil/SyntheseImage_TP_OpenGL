var namespacegk_1_1gk =
[
    [ "TVec2", "structgk_1_1gk_1_1TVec2.html", "structgk_1_1gk_1_1TVec2" ],
    [ "TVec3", "structgk_1_1gk_1_1TVec3.html", "structgk_1_1gk_1_1TVec3" ],
    [ "VecColor", "structgk_1_1gk_1_1VecColor.html", "structgk_1_1gk_1_1VecColor" ],
    [ "TVec4", "structgk_1_1gk_1_1TVec4.html", "structgk_1_1gk_1_1TVec4" ],
    [ "Mat4", "structgk_1_1gk_1_1Mat4.html", "structgk_1_1gk_1_1Mat4" ],
    [ "Vector", "classgk_1_1gk_1_1Vector.html", "classgk_1_1gk_1_1Vector" ],
    [ "Color", "classgk_1_1gk_1_1Color.html", "classgk_1_1gk_1_1Color" ],
    [ "Point", "classgk_1_1gk_1_1Point.html", "classgk_1_1gk_1_1Point" ],
    [ "HPoint", "classgk_1_1gk_1_1HPoint.html", "classgk_1_1gk_1_1HPoint" ],
    [ "Normal", "classgk_1_1gk_1_1Normal.html", "classgk_1_1gk_1_1Normal" ],
    [ "BasicRay", "structgk_1_1gk_1_1BasicRay.html", "structgk_1_1gk_1_1BasicRay" ],
    [ "Ray", "structgk_1_1gk_1_1Ray.html", "structgk_1_1gk_1_1Ray" ],
    [ "Hit", "structgk_1_1gk_1_1Hit.html", "structgk_1_1gk_1_1Hit" ],
    [ "BBox", "classgk_1_1gk_1_1BBox.html", "classgk_1_1gk_1_1BBox" ]
];