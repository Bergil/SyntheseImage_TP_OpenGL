var structnv_1_1UIGlyph =
[
    [ "advance", "structnv_1_1UIGlyph.html#aa3825aea82bed73a88dfae73e116f587", null ],
    [ "tex_h", "structnv_1_1UIGlyph.html#a59c75c89367e7af217014207aba28098", null ],
    [ "tex_w", "structnv_1_1UIGlyph.html#ad43be7701344fae6b3c5bcf0dcf9337f", null ],
    [ "tex_xmax", "structnv_1_1UIGlyph.html#a63c6bd8b0114cbc37e75f21ae935d6f9", null ],
    [ "tex_xmin", "structnv_1_1UIGlyph.html#a3248cd73d081e9ddcf431f510285da2a", null ],
    [ "tex_ymax", "structnv_1_1UIGlyph.html#aebbc7079de4bfc3651fa40019c9b1c29", null ],
    [ "tex_ymin", "structnv_1_1UIGlyph.html#a70175a545511c559037069792140f656", null ],
    [ "xmax", "structnv_1_1UIGlyph.html#ad94d781e0e81d6161ba17cd051c21ca1", null ],
    [ "xmin", "structnv_1_1UIGlyph.html#a65c4b00dface90001c6c81cfc78fdb42", null ],
    [ "ymax", "structnv_1_1UIGlyph.html#a3e11f81c711cb2b6875af675387f14b9", null ],
    [ "ymin", "structnv_1_1UIGlyph.html#a67e04b19c6fcc999673ba5fa31aa25f7", null ]
];