var classnv_1_1UIFont =
[
    [ "UIFont", "classnv_1_1UIFont.html#af2f6101b462f19604fae4af1c2ed752b", null ],
    [ "~UIFont", "classnv_1_1UIFont.html#a65822d04640808275ad0de01a8375548", null ],
    [ "getFontHeight", "classnv_1_1UIFont.html#ad6d1ac31113b838cc40b079ac9dc87d2", null ],
    [ "getFontTexture", "classnv_1_1UIFont.html#adc3f62f25d228a163a33804feb622b1d", null ],
    [ "getGlyph", "classnv_1_1UIFont.html#a572e51c8e2885c8f45254d769b62c14e", null ],
    [ "getPickedCharNb", "classnv_1_1UIFont.html#af3accf94e63dc4db6c25faba3a7c38b8", null ],
    [ "getTextLineWidth", "classnv_1_1UIFont.html#a5ecddd238b14bf52de632d7815706b4b", null ],
    [ "getTextLineWidthAt", "classnv_1_1UIFont.html#a117d52781effbaef1da96cbec6a35cb0", null ],
    [ "getTextRect", "classnv_1_1UIFont.html#a5c9689834c8c284518af174a86d7ad53", null ],
    [ "getTextRect", "classnv_1_1UIFont.html#aae9951c0d33b52346153b69997ecb69d", null ],
    [ "getTextSize", "classnv_1_1UIFont.html#a0e39b77508e56690032a7c854e2b14c4", null ],
    [ "init", "classnv_1_1UIFont.html#a87031a9d6d174f20d39560cd6875dd48", null ],
    [ "m_glyphs", "classnv_1_1UIFont.html#ac129bac9298399fa0c63114a92ca11ee", null ],
    [ "m_line_skip", "classnv_1_1UIFont.html#a745eb0d21856b4b449edada804950114", null ],
    [ "m_texture", "classnv_1_1UIFont.html#a354a27ebd4d3786f3fbbf8c7edb80e05", null ]
];