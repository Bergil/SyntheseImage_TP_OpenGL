var structgk_1_1Quad =
[
    [ "Quad", "structgk_1_1Quad.html#adcf15c3b092d7bddd4289e58b8574b7a", null ],
    [ "Quad", "structgk_1_1Quad.html#a344044d80c206dabe1b8870f492c24d4", null ],
    [ "point", "structgk_1_1Quad.html#a38e643e8db62c64a70593118f87ee0fe", null ],
    [ "a", "structgk_1_1Quad.html#a0b84a9011c7eecc680192017f49e73cc", null ],
    [ "b", "structgk_1_1Quad.html#aa16f049c3a0333e292e8dd54e4dcb30f", null ],
    [ "c", "structgk_1_1Quad.html#a1668e4e5ab850c995b824fcefc4d59db", null ],
    [ "d", "structgk_1_1Quad.html#a8a404944f616c26d407dbde3e13f27d6", null ],
    [ "id", "structgk_1_1Quad.html#a3ae2509696dd82e4c60f0d89a442a629", null ]
];