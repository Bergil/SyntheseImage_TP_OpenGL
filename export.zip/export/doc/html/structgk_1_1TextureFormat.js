var structgk_1_1TextureFormat =
[
    [ "TextureFormat", "structgk_1_1TextureFormat.html#ac05e6c9084df0b61b04ea412b6ab9a8c", null ],
    [ "TextureFormat", "structgk_1_1TextureFormat.html#ace22a21678fee4e52750bde1f57ff782", null ],
    [ "data_format", "structgk_1_1TextureFormat.html#aeac66901271960493aa20b1def296e50", null ],
    [ "data_type", "structgk_1_1TextureFormat.html#ab808c8bf166241a75f923e64940f7dfa", null ],
    [ "fixed_samples", "structgk_1_1TextureFormat.html#a0a1b33b924608aec9ba6cedf0be4e4a9", null ],
    [ "internal", "structgk_1_1TextureFormat.html#aa235b89c45145f7d0e540251a9e51a19", null ],
    [ "samples", "structgk_1_1TextureFormat.html#aa1c46ac36f3a28d40b2b30302c5b30a8", null ]
];