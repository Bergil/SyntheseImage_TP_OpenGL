var structnv_1_1GLCore_1_1Draw_1_1buffer =
[
    [ "buffer", "structnv_1_1GLCore_1_1Draw_1_1buffer.html#ac932cce47c4d29f1aa82d60962ce42b7", null ],
    [ "data", "structnv_1_1GLCore_1_1Draw_1_1buffer.html#ac62e3e9a1b38a98708723a6a851dd7d5", null ],
    [ "data_offset", "structnv_1_1GLCore_1_1Draw_1_1buffer.html#ae48569c6c4ef74a96166305fb1d4190a", null ],
    [ "index", "structnv_1_1GLCore_1_1Draw_1_1buffer.html#add664f76b5b070a433356c58ce1fda01", null ],
    [ "index_offset", "structnv_1_1GLCore_1_1Draw_1_1buffer.html#ad04087b4bf3421fda1dbe2ff51e24e58", null ]
];