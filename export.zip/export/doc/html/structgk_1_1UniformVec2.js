var structgk_1_1UniformVec2 =
[
    [ "UniformVec2", "structgk_1_1UniformVec2.html#a53729c355f887902107db597113cc5fd", null ],
    [ "operator=", "structgk_1_1UniformVec2.html#a52c5df8f9bc084d43c43f1b1b7ad7498", null ],
    [ "update", "structgk_1_1UniformVec2.html#a3e6e81b1c0fc5abfe90007df5bb67ccc", null ]
];