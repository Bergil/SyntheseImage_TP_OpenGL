var structgk_1_1gk_1_1BasicRay =
[
    [ "BasicRay", "structgk_1_1gk_1_1BasicRay.html#a1a17911a3f83e312b2c1449f2b25f079", null ],
    [ "BasicRay", "structgk_1_1gk_1_1BasicRay.html#a268fdc57fb5e1cd5e6665c75049766f3", null ],
    [ "BasicRay", "structgk_1_1gk_1_1BasicRay.html#acd0463327ccaf74745ac052396bfdb8d", null ],
    [ "operator()", "structgk_1_1gk_1_1BasicRay.html#aa1563084fa81760a5b86a703ee264c9f", null ],
    [ "d", "structgk_1_1gk_1_1BasicRay.html#aa6ba3a108d98f0e10c16200acf141b4e", null ],
    [ "id", "structgk_1_1gk_1_1BasicRay.html#aa70c543ba3ef2e8c8b490f823d74f230", null ],
    [ "o", "structgk_1_1gk_1_1BasicRay.html#a1f61ebe94ed73252e03fea59632ec5fe", null ],
    [ "tmax", "structgk_1_1gk_1_1BasicRay.html#a9823d83a4aa17889b3db2c068cfa86cb", null ]
];