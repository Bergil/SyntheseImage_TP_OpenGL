var structgk_1_1glsl_1_1grmat_3_01T_00_014u_01_4 =
[
    [ "grmat", "structgk_1_1glsl_1_1grmat_3_01T_00_014u_01_4.html#a314be618c9acc44d1fd59c0d22b481aa", null ],
    [ "operator const T *", "structgk_1_1glsl_1_1grmat_3_01T_00_014u_01_4.html#a80c54222b2753e91f39440ef84825110", null ],
    [ "operator T *", "structgk_1_1glsl_1_1grmat_3_01T_00_014u_01_4.html#abc30cc76bc211e5f7ba4fd57f81e9a08", null ],
    [ "operator[]", "structgk_1_1glsl_1_1grmat_3_01T_00_014u_01_4.html#ad5dcc23d515950e5198101e81939c673", null ],
    [ "operator[]", "structgk_1_1glsl_1_1grmat_3_01T_00_014u_01_4.html#a9b895f39a3b80887c3b8bd5ad040e353", null ],
    [ "row", "structgk_1_1glsl_1_1grmat_3_01T_00_014u_01_4.html#a78fa2d12396d104cfbd2db8c2d0b2e2a", null ]
];