var structgk_1_1Mesh =
[
    [ "Mesh", "structgk_1_1Mesh.html#a04ea8f7a3887b0652baa43d0734c3f84", null ],
    [ "pntriangle", "structgk_1_1Mesh.html#ae701f2ea2d217250d1e0b4245687543d", null ],
    [ "ptntriangle", "structgk_1_1Mesh.html#a0793d400324284eb6dfe5a3ef25094c7", null ],
    [ "triangle", "structgk_1_1Mesh.html#af34399b77507f8f3cdfd925203709da9", null ],
    [ "triangleCount", "structgk_1_1Mesh.html#a719e644f89bc9d2a15eaf75900d2f697", null ],
    [ "triangleMaterial", "structgk_1_1Mesh.html#afa2521c56b4acbdca8bbdc851f631e24", null ],
    [ "box", "structgk_1_1Mesh.html#aadbe41edfd8d0d1f686db582dd637566", null ],
    [ "filename", "structgk_1_1Mesh.html#a803033bcfbec31995183056cb4fdd3cc", null ],
    [ "groups", "structgk_1_1Mesh.html#aa3e755749a0601aa24cf8c7205966db5", null ],
    [ "indices", "structgk_1_1Mesh.html#a63515e23829968f27c8879b4cd4f02ef", null ],
    [ "materials", "structgk_1_1Mesh.html#a6e1ea37a3106986184f765385d5dba03", null ],
    [ "normals", "structgk_1_1Mesh.html#a1888b5100e963b65040d5379f34661fd", null ],
    [ "positions", "structgk_1_1Mesh.html#ac2e5f2721ac269a29579a279845d716a", null ],
    [ "texcoords", "structgk_1_1Mesh.html#ab76fb9fab2dcc7792748bc5a6e691dd4", null ]
];