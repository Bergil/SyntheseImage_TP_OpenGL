var classgk_1_1GLCounter =
[
    [ "GLCounter", "classgk_1_1GLCounter.html#a8dfa9d03122af287aa9e17185d728a5a", null ],
    [ "GLCounter", "classgk_1_1GLCounter.html#af659d48402075e8c0a07dc1d4cc3bea3", null ],
    [ "~GLCounter", "classgk_1_1GLCounter.html#a85d5dd4b0c49ee26c6cfd7c5c6a9ef04", null ],
    [ "cpu64", "classgk_1_1GLCounter.html#aec70f4bf18213cd8548164d94e03cd03", null ],
    [ "create", "classgk_1_1GLCounter.html#a6e118bdbefe2ef7e7b219b8b40403afe", null ],
    [ "gpu64", "classgk_1_1GLCounter.html#a6e6b85c6c930f3ab9525fdb35e15243a", null ],
    [ "release", "classgk_1_1GLCounter.html#ad3db014874dab64ee8531b6573eb5fb8", null ],
    [ "start", "classgk_1_1GLCounter.html#a3be618a9e54262489283a49e52e888c9", null ],
    [ "state", "classgk_1_1GLCounter.html#a16688537a3733425c155e006af472d78", null ],
    [ "stop", "classgk_1_1GLCounter.html#aa76a07556f3bfdc52c0fac3ab1ec93ef", null ],
    [ "summary", "classgk_1_1GLCounter.html#a4859bf1c76b17016bdd738fb36d54d0e", null ],
    [ "sync", "classgk_1_1GLCounter.html#acee59998fd3d578c880d2d1ef90cd6c0", null ],
    [ "counter0", "classgk_1_1GLCounter.html#a539ca20e10cfecd8cad66364d493c2ed", null ],
    [ "counter1", "classgk_1_1GLCounter.html#a3f29f752eb0b4efa635382cfbb1e0333", null ],
    [ "cpu_value", "classgk_1_1GLCounter.html#a61c41140af1ee76ca3ca330bbe3a90d3", null ],
    [ "cpu_value0", "classgk_1_1GLCounter.html#a88b9834feece1d66198cbebb6ab21470", null ],
    [ "cpu_value1", "classgk_1_1GLCounter.html#aa88af47961719a02c7b539b1bbda4fdd", null ],
    [ "started", "classgk_1_1GLCounter.html#a321547c69a818844c700e8d3aceb4431", null ],
    [ "value", "classgk_1_1GLCounter.html#aa37ba9698bb40864eee75bfe8040d3c7", null ]
];