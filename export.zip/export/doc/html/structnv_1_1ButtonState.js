var structnv_1_1ButtonState =
[
    [ "cursor", "structnv_1_1ButtonState.html#aa0df04f1a20872d282e01c593beb6b43", null ],
    [ "state", "structnv_1_1ButtonState.html#a82cb22e9503c86478a91c59bd73c37ac", null ],
    [ "time", "structnv_1_1ButtonState.html#a57669871208abc2b484c6a7735f41c3c", null ]
];