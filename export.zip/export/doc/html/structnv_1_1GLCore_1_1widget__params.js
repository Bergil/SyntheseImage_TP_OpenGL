var structnv_1_1GLCore_1_1widget__params =
[
    [ "widget_params", "structnv_1_1GLCore_1_1widget__params.html#af669c2b9254f041cb08699d12b3ebc58", null ],
    [ "apply", "structnv_1_1GLCore_1_1widget__params.html#a184106304af20e2fd5172d2f14e45cc2", null ],
    [ "operator!=", "structnv_1_1GLCore_1_1widget__params.html#a9852a51c627449c17f102d1ef80059ee", null ],
    [ "operator==", "structnv_1_1GLCore_1_1widget__params.html#a34215ff68d4d1732675423493e319b80", null ],
    [ "border", "structnv_1_1GLCore_1_1widget__params.html#a3970854e375a290bf2ed4c883778162d", null ],
    [ "borderId", "structnv_1_1GLCore_1_1widget__params.html#aeac67b255912927a435b2cd6a01117d0", null ],
    [ "fill", "structnv_1_1GLCore_1_1widget__params.html#afaa903e7ad6d50896cbd0189e4cc24be", null ],
    [ "fillId", "structnv_1_1GLCore_1_1widget__params.html#afd575a0ce1e74babd2e16e1127449c4a", null ],
    [ "program", "structnv_1_1GLCore_1_1widget__params.html#a933712c3da9687eb37e55733560e1112", null ],
    [ "zones", "structnv_1_1GLCore_1_1widget__params.html#a2b31fea54b6659fe3af11d9c58f455e7", null ]
];