var structgk_1_1Face =
[
    [ "Face", "structgk_1_1Face.html#a1ef80ef218062462cdb32f799c45df25", null ],
    [ "push_back", "structgk_1_1Face.html#ae053a8101f6f2dc24cdb75eaf948bb2b", null ],
    [ "n", "structgk_1_1Face.html#a4fdbd03a0298e82ee787051504356d1d", null ],
    [ "vertex", "structgk_1_1Face.html#ad569d672da6e6dfbbcdfecc148d703b1", null ]
];