var structgk_1_1Ray =
[
    [ "Ray", "structgk_1_1Ray.html#a6cf26ccffb1ec0b5487c0c197ccc345c", null ],
    [ "Ray", "structgk_1_1Ray.html#a036e3814dfc3bee8db79195117383d1f", null ],
    [ "Ray", "structgk_1_1Ray.html#adf1c2d9612de6b958556f40da4971363", null ],
    [ "isBackward", "structgk_1_1Ray.html#a041803a891a9dd284da7f3799da0000b", null ],
    [ "inv_d", "structgk_1_1Ray.html#a6723d04990c229a5de779884e72919a9", null ],
    [ "sign_d", "structgk_1_1Ray.html#a9bac28d238114817331680d80e8d6651", null ]
];