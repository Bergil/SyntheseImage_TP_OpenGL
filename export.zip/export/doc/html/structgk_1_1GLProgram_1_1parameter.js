var structgk_1_1GLProgram_1_1parameter =
[
    [ "parameter", "structgk_1_1GLProgram_1_1parameter.html#a1745b3ca72b1a31489d7cd4e8e901d46", null ],
    [ "parameter", "structgk_1_1GLProgram_1_1parameter.html#a7b28989f096595daa65de2923017dfc1", null ],
    [ "~parameter", "structgk_1_1GLProgram_1_1parameter.html#aa18f4e606784998852de77cc26e4739d", null ],
    [ "flags", "structgk_1_1GLProgram_1_1parameter.html#ad8fb97a13e48c50432626ea533ba9296", null ],
    [ "index", "structgk_1_1GLProgram_1_1parameter.html#aadec6a4a2bc4aaf3524d9ca7fcbef33e", null ],
    [ "location", "structgk_1_1GLProgram_1_1parameter.html#a04a8c745cf148765b986fb774ff4df15", null ],
    [ "name", "structgk_1_1GLProgram_1_1parameter.html#a9dc1acec05e6c9a069e30353c69a6ea9", null ],
    [ "size", "structgk_1_1GLProgram_1_1parameter.html#ae8df44e83710774c610bd7e323b1f5cc", null ],
    [ "type", "structgk_1_1GLProgram_1_1parameter.html#ae0b9624c6e267bd8feaa28b1864f90d3", null ]
];