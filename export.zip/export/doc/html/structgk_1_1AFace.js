var structgk_1_1AFace =
[
    [ "AFace", "structgk_1_1AFace.html#ae5e7ea66e2f25852ed2c5fde80b9fe29", null ],
    [ "edges", "structgk_1_1AFace.html#ac162ba4b1a7f43101263082943088542", null ],
    [ "faces", "structgk_1_1AFace.html#a419da166698557985905e2e639e4e96e", null ],
    [ "n", "structgk_1_1AFace.html#a750c927406c3d1218fa69ae4c3bdbfb1", null ]
];