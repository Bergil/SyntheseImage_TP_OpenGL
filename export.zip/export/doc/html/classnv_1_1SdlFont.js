var classnv_1_1SdlFont =
[
    [ "SdlFont", "classnv_1_1SdlFont.html#a6616dab5e4233d99ae4f8219910e3af9", null ],
    [ "~SdlFont", "classnv_1_1SdlFont.html#a48ad63b49db0ef88f1d965bdb5f8d3cf", null ],
    [ "init", "classnv_1_1SdlFont.html#a3ca8c7027bc3175e82100218ce99cf13", null ]
];