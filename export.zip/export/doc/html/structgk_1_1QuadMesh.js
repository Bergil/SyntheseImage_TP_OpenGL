var structgk_1_1QuadMesh =
[
    [ "QuadMesh", "structgk_1_1QuadMesh.html#a799afe5216043d1cd984a7f17e139e54", null ],
    [ "buildNormals", "structgk_1_1QuadMesh.html#a430579eb28b914b6f4d0c7c0b88e1453", null ],
    [ "quad", "structgk_1_1QuadMesh.html#acba8cf9da0f9ec62ae52120abbd45bae", null ],
    [ "quadMaterial", "structgk_1_1QuadMesh.html#a74e261c2e667bb841ca9b1de02586608", null ],
    [ "afaces", "structgk_1_1QuadMesh.html#a172847d3f9b213a8f20d7dd815f74309", null ],
    [ "box", "structgk_1_1QuadMesh.html#a1502299f83204368698f475a5cd3e1f8", null ],
    [ "faces", "structgk_1_1QuadMesh.html#a8c8a5e183b5b7eae1cb86b336c0d358c", null ],
    [ "filename", "structgk_1_1QuadMesh.html#a04e57a48d52c21688b5130d4b8d34bbd", null ],
    [ "groups", "structgk_1_1QuadMesh.html#af96e0f31c7f92f3caa9f61279d1f5bdc", null ],
    [ "materials", "structgk_1_1QuadMesh.html#a406da2a0855cf5db105f10b46bef4b41", null ],
    [ "normals", "structgk_1_1QuadMesh.html#a0da750a2d3816e29fba7be555bc06c1b", null ],
    [ "positions", "structgk_1_1QuadMesh.html#abc6d386218b84755f0ce25952cc5dda5", null ],
    [ "texcoords", "structgk_1_1QuadMesh.html#afff91a5589ce6972f9e39d8532197d72", null ]
];