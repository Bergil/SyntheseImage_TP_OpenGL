var structnv_1_1Point =
[
    [ "Point", "structnv_1_1Point.html#a5e78dab6dfd4feada99db88c7a5553c7", null ],
    [ "Point", "structnv_1_1Point.html#a327f5767e99c5574b53e4baf76ab205d", null ],
    [ "Point", "structnv_1_1Point.html#aba26b74ed4bb68c5ada5a02fa1c2fdf2", null ],
    [ "operator=", "structnv_1_1Point.html#afe7e644bc0bde01f395b5cc3abcd271e", null ],
    [ "x", "structnv_1_1Point.html#a070650cc35b9817afdf3f8dd4509954c", null ],
    [ "y", "structnv_1_1Point.html#aeefe39937998654d731e8728e3713836", null ]
];