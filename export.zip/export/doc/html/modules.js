var modules =
[
    [ "representation de points, vecteurs, normales, couleurs, etc.", "group__Geometry.html", "group__Geometry" ],
    [ "representation et gestions des objets openGL.", "group__OpenGL.html", "group__OpenGL" ],
    [ "representation matrices homogenes, transformations, compositions de transformations, etc.", "group__Transform.html", "group__Transform" ]
];