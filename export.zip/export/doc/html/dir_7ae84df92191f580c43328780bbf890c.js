var dir_7ae84df92191f580c43328780bbf890c =
[
    [ "nvGLCoreDraw.h", "nvGLCoreDraw_8h_source.html", null ],
    [ "nvGLCorePainter.h", "nvGLCorePainter_8h_source.html", null ],
    [ "nvSDLContext.h", "nvSDLContext_8h_source.html", null ],
    [ "nvSDLFont.h", "nvSDLFont_8h_source.html", null ],
    [ "nvTweak.h", "nvTweak_8h_source.html", null ],
    [ "nvWidgets.h", "nvWidgets_8h_source.html", null ]
];