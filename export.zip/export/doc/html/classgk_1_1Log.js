var classgk_1_1Log =
[
    [ "ERROR", "classgk_1_1Log.html#a1cdeffd650aea0d17417fa2e198bba59a3a72473d8739661f5f6c152f9803e560", null ],
    [ "WARNING", "classgk_1_1Log.html#a1cdeffd650aea0d17417fa2e198bba59ae106530e8c1edf41fd9cf3a6aa2eab65", null ],
    [ "MESSAGE", "classgk_1_1Log.html#a1cdeffd650aea0d17417fa2e198bba59a983a5905bccf1bcc867e8227955b8af9", null ],
    [ "DEBUGLOG", "classgk_1_1Log.html#a1cdeffd650aea0d17417fa2e198bba59abe1992ce8b1eba2366f6f8d6ee5240b1", null ],
    [ "Log", "classgk_1_1Log.html#a26101ff29b71f73bedf3fc72bd94e7f6", null ],
    [ "~Log", "classgk_1_1Log.html#a6f62e32063e132443c3dbd09b2a75fb1", null ],
    [ "setOutputFile", "classgk_1_1Log.html#a92a730a802363a23b52788432dd47b61", null ],
    [ "setOutputLevel", "classgk_1_1Log.html#a9d2fea6482df77005f30ca8477e39e7a", null ],
    [ "write", "classgk_1_1Log.html#a2747ea8bf5212ac41c169e359bcac6f4", null ]
];