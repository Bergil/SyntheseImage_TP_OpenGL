var annotated =
[
    [ "gk", "namespacegk.html", "namespacegk" ],
    [ "nv", null, [
      [ "GLCore", null, [
        [ "vertex", "structnv_1_1GLCore_1_1vertex.html", "structnv_1_1GLCore_1_1vertex" ],
        [ "params", "structnv_1_1GLCore_1_1params.html", "structnv_1_1GLCore_1_1params" ],
        [ "Draw", "classnv_1_1GLCore_1_1Draw.html", "classnv_1_1GLCore_1_1Draw" ],
        [ "widget_program", "structnv_1_1GLCore_1_1widget__program.html", "structnv_1_1GLCore_1_1widget__program" ],
        [ "widget_params", "structnv_1_1GLCore_1_1widget__params.html", "structnv_1_1GLCore_1_1widget__params" ],
        [ "string_program", "structnv_1_1GLCore_1_1string__program.html", "structnv_1_1GLCore_1_1string__program" ],
        [ "string_params", "structnv_1_1GLCore_1_1string__params.html", "structnv_1_1GLCore_1_1string__params" ]
      ] ],
      [ "GLCorePainter", "classnv_1_1GLCorePainter.html", "classnv_1_1GLCorePainter" ],
      [ "SdlContext", "classnv_1_1SdlContext.html", "classnv_1_1SdlContext" ],
      [ "SdlFont", "classnv_1_1SdlFont.html", "classnv_1_1SdlFont" ],
      [ "Tweak", "structnv_1_1Tweak.html", "structnv_1_1Tweak" ],
      [ "Point", "structnv_1_1Point.html", "structnv_1_1Point" ],
      [ "Rect", "structnv_1_1Rect.html", "structnv_1_1Rect" ],
      [ "RGB8", "structnv_1_1RGB8.html", "structnv_1_1RGB8" ],
      [ "ButtonState", "structnv_1_1ButtonState.html", "structnv_1_1ButtonState" ],
      [ "Group", "structnv_1_1Group.html", "structnv_1_1Group" ],
      [ "UIGlyph", "structnv_1_1UIGlyph.html", "structnv_1_1UIGlyph" ],
      [ "UIFontTexture", "structnv_1_1UIFontTexture.html", "structnv_1_1UIFontTexture" ],
      [ "UIFont", "classnv_1_1UIFont.html", "classnv_1_1UIFont" ],
      [ "UIPainter", "classnv_1_1UIPainter.html", "classnv_1_1UIPainter" ],
      [ "UIContext", "classnv_1_1UIContext.html", "classnv_1_1UIContext" ]
    ] ],
    [ "rgbe_header_info", "structrgbe__header__info.html", "structrgbe__header__info" ]
];