var structnv_1_1GLCore_1_1string__params =
[
    [ "string_params", "structnv_1_1GLCore_1_1string__params.html#aff2e224dff300b0e7bf7d06cd2decdd2", null ],
    [ "apply", "structnv_1_1GLCore_1_1string__params.html#a66a5165731e4dec5a4e51304b33d3bd0", null ],
    [ "operator!=", "structnv_1_1GLCore_1_1string__params.html#aaf31d655313801d9ef2499e24673f8b7", null ],
    [ "operator==", "structnv_1_1GLCore_1_1string__params.html#a97ff844130136412415d56a3d00ee36b", null ],
    [ "color", "structnv_1_1GLCore_1_1string__params.html#ade962d2ce31c35d4b4524ab114ce19e2", null ],
    [ "colorId", "structnv_1_1GLCore_1_1string__params.html#a300b4eccf7dba8a9e07881578254653f", null ],
    [ "font", "structnv_1_1GLCore_1_1string__params.html#a935df1c92ef45310e6ea576536bea9f9", null ],
    [ "program", "structnv_1_1GLCore_1_1string__params.html#a5fbd2da2fd47ffcfcd6772590cafb8a1", null ]
];