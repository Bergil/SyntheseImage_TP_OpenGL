var structnv_1_1GLCore_1_1string__program =
[
    [ "string_program", "structnv_1_1GLCore_1_1string__program.html#ad554904913532dca7e0bf2b4def1f63a", null ],
    [ "color", "structnv_1_1GLCore_1_1string__program.html#a45d69dc3326578a52a30874744105013", null ],
    [ "font", "structnv_1_1GLCore_1_1string__program.html#ad18677f38e4ad1af2fee6d94de034ee2", null ],
    [ "program", "structnv_1_1GLCore_1_1string__program.html#ab24cd2711b5c08021a327095f0786f5f", null ],
    [ "projection", "structnv_1_1GLCore_1_1string__program.html#ac9ce0260b635cf1ac971660afcaff3ed", null ]
];