var structgk_1_1MeshData =
[
    [ "MeshData", "structgk_1_1MeshData.html#a7570c42a2bf248dc23449ee354850e6e", null ],
    [ "afaces", "structgk_1_1MeshData.html#ac8a7bda15b4b924b1f437574eee7c337", null ],
    [ "box", "structgk_1_1MeshData.html#af825e270f68da121a5970c534102e488", null ],
    [ "faces", "structgk_1_1MeshData.html#afeb5fbe5c90748aecf219ae7981d94de", null ],
    [ "has_material", "structgk_1_1MeshData.html#a3a73cbccbda143f23ce9cc28fcdeec0e", null ],
    [ "has_normal", "structgk_1_1MeshData.html#a7fbf9674cdba27e937bc3d4c28442bc0", null ],
    [ "has_texcoord", "structgk_1_1MeshData.html#aaa2cd9f1697d40f817728b55204ba7ea", null ],
    [ "materials", "structgk_1_1MeshData.html#ab75e8a09c4063b4d3e334609e2893059", null ],
    [ "normals", "structgk_1_1MeshData.html#a444b7021b5ef37bbf818918e4946bbea", null ],
    [ "positions", "structgk_1_1MeshData.html#a530fe8abf32fb7a45b24b149b9923a7f", null ],
    [ "texcoords", "structgk_1_1MeshData.html#a1a6298f9a25ac36ddc091c8c5202fbf0", null ]
];