var structgk_1_1GLCounterState =
[
    [ "GLCounterState", "structgk_1_1GLCounterState.html#a991f4007d4bf599166c9e1dc67319c1b", null ],
    [ "summary", "structgk_1_1GLCounterState.html#a9be464e7e16599e46e49b144cd2c3edf", null ],
    [ "cpu_start", "structgk_1_1GLCounterState.html#aec2233f97d3dcf805f1671dbbaed906b", null ],
    [ "cpu_stop", "structgk_1_1GLCounterState.html#a8cd5dec1493a7c73b63758700db8829e", null ],
    [ "cpu_time", "structgk_1_1GLCounterState.html#a6cc590f8f9f1f4d6f0c2c3cc6608b27a", null ],
    [ "gpu_start", "structgk_1_1GLCounterState.html#a59b163a3bec86769cfcfeb50b6556712", null ],
    [ "gpu_stop", "structgk_1_1GLCounterState.html#a05a5b587c2d5ab0b5d4ba4d70688351e", null ],
    [ "gpu_time", "structgk_1_1GLCounterState.html#a7cffd14f9ea7c64f25b5b6715a5ab19d", null ]
];