var structgk_1_1UniformVec3 =
[
    [ "UniformVec3", "structgk_1_1UniformVec3.html#a0818ce76716d3c0fd89a24cb11624fb3", null ],
    [ "operator=", "structgk_1_1UniformVec3.html#ac9364f561d58f8c29d25e9923685897e", null ],
    [ "update", "structgk_1_1UniformVec3.html#acac1e5f4c385fe7c2cd052f7ed797d09", null ]
];