var structgk_1_1Hit =
[
    [ "Hit", "structgk_1_1Hit.html#a3dffda29bae51b4c132db835c1659c3a", null ],
    [ "Hit", "structgk_1_1Hit.html#a589a716e17287fd0ad5daf0e4615bf2d", null ],
    [ "~Hit", "structgk_1_1Hit.html#a2876be023ef6a852e5d7f6a0a8564f38", null ],
    [ "child_id", "structgk_1_1Hit.html#a0778f03a693ec8528722888f1bb4c1dd", null ],
    [ "n", "structgk_1_1Hit.html#a2097204e13d996dcdd1e71722b28d9c8", null ],
    [ "node_id", "structgk_1_1Hit.html#af86ade6fb1cd85e1a22596fdef0e53d7", null ],
    [ "object_id", "structgk_1_1Hit.html#a1d2606b522afac61a4eb9d6eb395f8e6", null ],
    [ "p", "structgk_1_1Hit.html#a617d26897688ca1f584e54bd6e828737", null ],
    [ "t", "structgk_1_1Hit.html#a112c1de3944dde7daee09e8c174203a2", null ],
    [ "t1", "structgk_1_1Hit.html#a11c408af6857143a1c515a891f19e4dd", null ],
    [ "t2", "structgk_1_1Hit.html#aa1207d74d9d31687700352b8a2ea73e2", null ],
    [ "tmin", "structgk_1_1Hit.html#a177166a44665d3d15a1b9c81d1c39c94", null ],
    [ "u", "structgk_1_1Hit.html#afe45831508bcdd6eeaec86a7ac09afaa", null ],
    [ "user_data", "structgk_1_1Hit.html#a82e09064ec453c2c64a22b6168509340", null ],
    [ "v", "structgk_1_1Hit.html#a31000c7ab55b34104ad26e226c507932", null ]
];