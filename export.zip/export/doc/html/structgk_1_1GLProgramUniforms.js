var structgk_1_1GLProgramUniforms =
[
    [ "GLProgramUniforms", "structgk_1_1GLProgramUniforms.html#abd23acfe68ee6966891dd8b213025fca", null ],
    [ "GLProgramUniforms", "structgk_1_1GLProgramUniforms.html#a04af55b6bf1c6c21de12f1d07693b18c", null ],
    [ "~GLProgramUniforms", "structgk_1_1GLProgramUniforms.html#ae2ab7466ffc4a99ef3e1ae47c4d0ed2e", null ],
    [ "assign", "structgk_1_1GLProgramUniforms.html#ae1e7b0681f52c19ff4d16693d6363347", null ],
    [ "find", "structgk_1_1GLProgramUniforms.html#acfed5b7a09ca30b1e7599e9dc0173f89", null ],
    [ "summary", "structgk_1_1GLProgramUniforms.html#a50e65ba58e57c9dd9215b751e07fcaa0", null ],
    [ "update", "structgk_1_1GLProgramUniforms.html#a28a1f45254cb677ca575d575256f3661", null ],
    [ "names", "structgk_1_1GLProgramUniforms.html#a2216e673cb3d911d4f3fb25a48fa363f", null ],
    [ "program", "structgk_1_1GLProgramUniforms.html#aa6a851ffecdcd3c2a9ce50fde1e13fd2", null ],
    [ "program_changes", "structgk_1_1GLProgramUniforms.html#a710dddb96f5954e2db75a5cca4c9aba8", null ],
    [ "values", "structgk_1_1GLProgramUniforms.html#a8993106e99d24bd298e1286067a3591e", null ]
];