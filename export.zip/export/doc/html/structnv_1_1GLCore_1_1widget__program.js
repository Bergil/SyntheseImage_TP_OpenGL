var structnv_1_1GLCore_1_1widget__program =
[
    [ "widget_program", "structnv_1_1GLCore_1_1widget__program.html#af3d86f2cb0aa4bc1c5e9dd79d3a3c040", null ],
    [ "borderColor", "structnv_1_1GLCore_1_1widget__program.html#a473199c48efc6bf1517c6f733adce8dd", null ],
    [ "fillColor", "structnv_1_1GLCore_1_1widget__program.html#adbfa469dbca39253c3331ed5458ae3af", null ],
    [ "program", "structnv_1_1GLCore_1_1widget__program.html#af0a3434cd62a1047311c6445dc49aeda", null ],
    [ "projection", "structnv_1_1GLCore_1_1widget__program.html#acf7d653a2b35afbdb5a963d6d5b02dad", null ],
    [ "zones", "structnv_1_1GLCore_1_1widget__program.html#a0ac2313af8aeae599aa6623377737d5b", null ]
];